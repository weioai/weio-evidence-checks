# Weio evidence checks

Two Python MCP servers check the consistency of evidence supplied by their caller. They run locally over stdio and do not connect to a provider, deployment, payment system or Weio service.

**Release candidate:** this package has not been published. Its license, independent review and package verification must be completed before release. The package intentionally has a `Private :: Do Not Upload` classifier until those checks pass.

| Command | MCP tool | Input and result |
| --- | --- | --- |
| `weio-connector-readiness` | `validate_connector_readiness` | Redacted OAuth test assertions; returns PASS, FAIL or UNKNOWN for the supplied evidence. |
| `weio-production-provenance` | `verify_production_provenance` | Expected and supplied source, build, deployment and public identifiers and SHA-256 digests; reports mismatches or missing observations. |

PASS means the supplied values pass the consistency rules. It does not authenticate evidence, prove a live system works, authorize a release or grant approval. Output includes `approval_granted: false` and the remaining independent checks.

## Install the candidate from source

Requires Python 3.10 or later. From this directory, in a separate virtual environment:

```sh
python -m pip install .
weio-connector-readiness --self-test
weio-production-provenance --self-test
```

No runtime Python dependencies are declared. Source installation may fetch the setuptools build dependency. The commands start a stdio server when no option is supplied.

## See the input before calling a tool

```sh
weio-connector-readiness --schema
weio-connector-readiness --example
weio-production-provenance --schema
weio-production-provenance --example
```

Examples are synthetic and establish no real-world readiness. A work reference such as `WQ-101` is a caller-chosen label; no Weio account or company queue is required. Use logical labels for scope and evidence IDs, not filesystem paths, URLs or credentials. Do not send tokens, authorization headers, private keys, customer records or raw logs. Secret-pattern rejection is a limited input check, not a comprehensive data-loss prevention guarantee.

## Configure a stdio client

This is a configuration example, not a claim that every client has been tested. Use absolute paths to the commands in your virtual environment if its executable directory is not on your client's PATH.

```json
{
  "mcpServers": {
    "weio-connector-readiness": {"command": "weio-connector-readiness", "args": []},
    "weio-production-provenance": {"command": "weio-production-provenance", "args": []}
  }
}
```

The retained servers negotiate protocol versions `2025-11-25`, `2025-06-18` and `2025-03-26`. Full MCP conformance and named-client interoperability require separate verification. These servers expose no HTTP listener.

## Contribute

Tests use synthetic data:

```sh
PYTHONPATH=src python -m unittest discover -s tests -v
```

Weio is operated by AI agents under human ownership. Learn about the company at [weio.ai](https://weio.ai). This package supplies software checks; it does not supply access to Weio's operator accounts.
